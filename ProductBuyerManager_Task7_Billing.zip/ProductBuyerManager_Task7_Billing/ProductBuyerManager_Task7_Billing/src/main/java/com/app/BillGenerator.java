package com.app;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BillGenerator {
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

    public String generateBillText(Bill bill) {
        StringBuilder sb = new StringBuilder();

        // Header
        sb.append("========================================\n");
        sb.append("            INVOICE RECEIPT\n");
        sb.append("========================================\n\n");

        // Buyer Details
        sb.append("Buyer Information:\n");
        sb.append("Name: ").append(bill.getBuyerName()).append("\n");
        sb.append("Address: ").append(bill.getBuyerAddress()).append("\n");
        sb.append("Contact: ").append(bill.getContactNumber()).append("\n");
        sb.append("Email: ").append(bill.getEmail()).append("\n\n");

        // Product Table Header
        sb.append(String.format("%-20s %-10s %-10s %-10s\n",
                "Product Name", "Qty", "Unit Price", "Total"));
        sb.append("----------------------------------------\n");

        // Product Items
        for (ProductItem item : bill.getProducts()) {
            sb.append(String.format("%-20s %-10d %-10.2f %-10.2f\n",
                    item.getProductName(),
                    item.getQuantity(),
                    item.getUnitPrice(),
                    item.getTotalPrice()));
        }

        // Summary
        sb.append("\n");
        sb.append("Subtotal: ").append(String.format("%.2f", bill.calculateSubtotal())).append("\n");
        sb.append("Total Amount Due: ").append(String.format("%.2f", bill.calculateTotal())).append("\n\n");

        // Transaction Details
        sb.append("Transaction Details:\n");
        sb.append("Transaction ID: ").append(bill.getTransactionId()).append("\n");
        sb.append("Purchase Date: ").append(dateFormat.format(bill.getPurchaseDate())).append("\n");
        sb.append("Payment Method: ").append(bill.getPaymentMethod()).append("\n");

        sb.append("\n========================================\n");
        sb.append("Thank you for your business!\n");
        sb.append("========================================\n");

        return sb.toString();
    }

    public void printBill(Bill bill) {
        System.out.println(generateBillText(bill));
    }

    // In a real implementation, these would have actual implementations
    public void saveToPDF(Bill bill, String filename) {
        System.out.println("Saving bill to PDF: " + filename);
        // PDF generation logic would go here
    }

    public void saveToCSV(Bill bill, String filename) {
        System.out.println("Saving bill to CSV: " + filename);
        // CSV generation logic would go here
    }

    public void emailBill(Bill bill, String emailAddress) {
        System.out.println("Emailing bill to: " + emailAddress);
        // Email sending logic would go here
    }
}