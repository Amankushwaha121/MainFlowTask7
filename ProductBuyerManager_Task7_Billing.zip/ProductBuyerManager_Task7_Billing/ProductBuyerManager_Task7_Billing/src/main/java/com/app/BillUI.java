package com.app;
import java.util.Date;
import java.util.Scanner;

public class BillUI {
    private BillGenerator billGenerator;
    private Scanner scanner;

    public BillUI() {
        this.billGenerator = new BillGenerator();
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        System.out.println("=== Bill Generation System ===");

        Bill bill = createSampleBill(); // In real app, this would collect user input

        while (true) {
            System.out.println("\nOptions:");
            System.out.println("1. Preview Bill");
            System.out.println("2. Print Bill");
            System.out.println("3. Save as PDF");
            System.out.println("4. Save as CSV");
            System.out.println("5. Email Bill");
            System.out.println("6. Exit");
            System.out.print("Select an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    billGenerator.printBill(bill);
                    break;
                case 2:
                    System.out.println("Printing bill...");
                    // Actual printing logic would go here
                    break;
                case 3:
                    billGenerator.saveToPDF(bill, "bill_" + bill.getTransactionId() + ".pdf");
                    break;
                case 4:
                    billGenerator.saveToCSV(bill, "bill_" + bill.getTransactionId() + ".csv");
                    break;
                case 5:
                    System.out.print("Enter email address: ");
                    String email = scanner.nextLine();
                    billGenerator.emailBill(bill, email);
                    break;
                case 6:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option!");
            }
        }
    }

    private Bill createSampleBill() {
        Bill bill = new Bill();
        bill.setBuyerName("John Doe");
        bill.setBuyerAddress("123 Main St, Cityville");
        bill.setContactNumber("555-1234");
        bill.setEmail("john.doe@example.com");
        bill.setTransactionId("TXN123456");
        bill.setPurchaseDate(new Date());
        bill.setPaymentMethod("Credit Card");

        bill.addProduct(new ProductItem("Laptop", 1, 999.99));
        bill.addProduct(new ProductItem("Mouse", 2, 19.99));
        bill.addProduct(new ProductItem("Keyboard", 1, 49.99));

        return bill;
    }

    public static void main(String[] args) {
        new BillUI().start();
    }
}