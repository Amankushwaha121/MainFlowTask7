package com.app;
import java.util.ArrayList;
import java.util.List;

public class BillSearch {
    private List<Bill> billDatabase;

    public BillSearch() {
        this.billDatabase = new ArrayList<>();
        // In a real app, this would load from actual database
    }

    public void addBill(Bill bill) {
        billDatabase.add(bill);
    }

    public Bill searchByTransactionId(String transactionId) {
        for (Bill bill : billDatabase) {
            if (bill.getTransactionId().equalsIgnoreCase(transactionId)) {
                return bill;
            }
        }
        return null;
    }

    public List<Bill> searchByBuyerName(String name) {
        List<Bill> results = new ArrayList<>();
        for (Bill bill : billDatabase) {
            if (bill.getBuyerName().toLowerCase().contains(name.toLowerCase())) {
                results.add(bill);
            }
        }
        return results;
    }
}