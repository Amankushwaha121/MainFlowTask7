 package com.app;
import java.util.ArrayList;

import java.util.Date;
import java.util.List;

public class Bill {
    private String buyerName;
    private String buyerAddress;
    private String contactNumber;
    private String email;
    private String transactionId;
    private Date purchaseDate;
    private String paymentMethod;
    private List<ProductItem> products;

    public Bill() {
        this.products = new ArrayList<>();
    }

    // Getters and Setters
    public String getBuyerName() { return buyerName; }
    public void setBuyerName(String buyerName) { this.buyerName = buyerName; }

    public String getBuyerAddress() { return buyerAddress; }
    public void setBuyerAddress(String buyerAddress) { this.buyerAddress = buyerAddress; }

    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }

    public Date getPurchaseDate() { return purchaseDate; }
    public void setPurchaseDate(Date purchaseDate) { this.purchaseDate = purchaseDate; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public List<ProductItem> getProducts() { return products; }

    public void addProduct(ProductItem product) {
        this.products.add(product);
    }

    public double calculateSubtotal() {
        return products.stream().mapToDouble(ProductItem::getTotalPrice).sum();
    }

    public double calculateTotal() {
        return calculateSubtotal();
    }
}